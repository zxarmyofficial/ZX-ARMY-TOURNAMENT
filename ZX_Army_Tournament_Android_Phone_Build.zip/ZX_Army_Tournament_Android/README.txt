ZX ARMY TOURNAMENT - Android Studio starter project

WHAT THIS IS
- A starter Android project that wraps the included tournament demo in an Android WebView.
- App name: ZX ARMY Tournament
- Package: com.zxarmy.tournament
- Theme: Red & Black
- Modes: Solo, Duo, Squad

IMPORTANT LIMITATIONS
- This is not a production tournament platform.
- Registration data is stored locally on the device only.
- The admin panel is a local demo, NOT a secure admin login.
- There is no online database, real-time sync, payment processing, or verified results.
- This version intentionally does not collect paid entry fees or cash-prize payments.
- Use only with organizer/guardian oversight and follow applicable game/platform rules.

BUILD APK
1. Install Android Studio on a computer.
2. Open this project folder in Android Studio.
3. Allow Gradle sync to complete (Android Studio may download the Android Gradle Plugin).
4. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio will show the APK output location, usually app/build/outputs/apk/debug/app-debug.apk.
6. For a distributable release, configure a release signing key in Android Studio. Keep the key private.

This environment did not build or sign an APK; this archive contains the Android Studio source project.

BUILD WITHOUT A COMPUTER (PHONE-ONLY OPTION)
A GitHub Actions workflow is included at .github/workflows/build-apk.yml. From your phone:
1. Sign in to GitHub in your browser and create a new repository.
2. Upload the contents of this project ZIP (extract it first using your phone's Files app; include the hidden .github folder).
3. Open the repository's Actions tab and run “Build ZX ARMY APK” (or wait for the first push build).
4. When the run finishes, open it and download the artifact named ZX-ARMY-Tournament-debug-APK.
5. Extract the artifact ZIP to get app-debug.apk, then open it on your phone and follow Android's install prompts. Only install APKs you built from source you trust.

The phone-only build uses GitHub's cloud build service and requires a GitHub account and internet. The APK is a debug build for testing, not a Play Store release.
